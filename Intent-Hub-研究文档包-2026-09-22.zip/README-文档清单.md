# Intent Hub 研究文档包

打包日期：2026-09-22
范围：当前 Intent Hub 工作区内的理论研究文档，包含当前计划、历史计划与调研报告。

建议先阅读 docs/research/2026-09-21-Jev启发的轻量语义决策模型研究计划.md（v1.0）。

保留原目录结构和原文；文档之间的相对链接可继续使用。源码引用需要原仓库，外部论文与项目链接需要联网。未包含源码、数据库、密钥配置或运行日志。

## 文件清单与 SHA-256

- docs/Jev 技术路线完整调研报告.md
  SHA-256: 667004C276F5618B1E69565B0B32243DB572FADE48F25BFB77EE9DAC5E4A840A
- docs/research/2026-09-17-dynamic-capability-routing-research.md
  SHA-256: 786092BFC6820A1CE6299740AB33DF194BDEAA686D536489C22ED2137B0B5DDF
- docs/research/2026-09-21-轻量语义决策与Agent路由相关工作调研.md
  SHA-256: BDBB3390B581D92D04BBD84A26F4D5ECA25FBEF61ED52CFF22D778D3B893F530
- docs/research/2026-09-21-Jev启发的轻量语义决策模型研究计划-v0.1.md
  SHA-256: E707016D55EFBC23A2AE676F860511F9BFF2E42EBC132F24EDCB3C8797A865A2
- docs/research/2026-09-21-Jev启发的轻量语义决策模型研究计划.md
  SHA-256: D1B62D93A28FC7EFA7F43AFC63D349694F5419A97AABBCA92DF7FBB4CFAA8C9E