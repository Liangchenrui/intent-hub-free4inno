# Intent Hub 路由接口文档

版本：0.3.0 · 更新日期：2026-09-29

本文对应当前工作区实现，包含新增的 `collection`、`upstream_id` 筛选参数。部署地址、密钥和示例中的标识须由接入方替换；文档不代表线上服务已升级。

## 1. 接口入口

| 契约 | 推荐固定路径 | 等价路径 | 请求文本字段 | 响应形式 |
| --- | --- | --- | --- | --- |
| BUPT | `POST /compat/bupt/route` | `POST /route` | `query` | `success/data/error` 对象 |
| master | `POST /compat/master/predict` | `POST /predict` | `text` | 路由结果数组 |

全部使用 `Content-Type: application/json`。固定兼容路径不受 `API_COMPAT_PROFILE` 影响。经内置前端 Nginx 访问时添加 `/api` 前缀，例如 `/api/compat/bupt/route`。

可导入的 BUPT OpenAPI 3.1 文件：[bupt-routing-api.openapi.yaml](../bupt-routing-api.openapi.yaml)。该文件描述 `/route` 契约；master 的 `/predict` 契约见本文第 5 节。

## 2. 鉴权

推荐请求头：

```http
Authorization: Bearer <ROUTE_API_KEY>
Content-Type: application/json
```

也支持 `X-API-Key: <ROUTE_API_KEY>`。管理员保存非空 `ROUTE_API_KEY` 后，两种路由契约统一使用该密钥。

未配置统一密钥时，`/route` 使用 `AUTH_CODE`，`/predict` 使用 `PREDICT_AUTH_KEY`。`/route` 无可用密钥时返回 401，不接受管理台登录签发的 API Key。`/predict` 在启用管理认证时也接受有效的管理 API Key；仅在无预测密钥且 `AUTH_ENABLED=false` 时允许匿名访问。路由密钥不授予管理权限。

## 3. 请求参数与范围

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `query` | string | `/route` 必填 | 用户文本；不能为空或仅含空白 |
| `text` | string | `/predict` 必填 | 用户文本；长度至少为 1；当前接口不额外拒绝纯空白文本 |
| `collection` | string 或 null | 否 | 本次检索的现有 Qdrant Collection；最大 255 字符；省略或 null 使用服务默认库 |
| `upstream_id` | string 或 null | 否 | 上游配置的稳定 `id`，对应路由来源 `source.instance`；省略或 null 不限来源 |
| `learn_from_fallback` | boolean | 否，仅 `/predict` | 默认 true；兜底命中后积累语料；测试调用建议 false。`/route` 不提供此控制字段 |

`collection`、`upstream_id` 会去除首尾空白；空字符串、纯空白字符串或非字符串值（null 除外）返回 400。未知的额外字段会被忽略，不应依赖它们控制行为。

`upstream_id` 不是上游名称、URL、Agent 原始 `source_id` 或 `route_key`。例如配置为 `{"id":"orders-platform","name":"orders"}` 时，请传 `orders-platform`。匹配区分大小写，只纳入 `source.type="upstream_agent"` 且 `source.instance` 相等的路由。

| 传参方式 | 实际检索范围 |
| --- | --- |
| 两项均不传 | 默认 Collection，来源不限 |
| 仅传 `collection` | 指定 Collection，来源不限 |
| 仅传 `upstream_id` | 默认 Collection 中该上游的路由 |
| 两项都传 | 指定 Collection 中该上游的路由（交集） |

筛选同时作用于正例、负例和 LLM 兜底，不会在未命中后扩大到其他来源或 Collection。不存在的 Collection 返回 400；未知上游、空库或无有效候选返回正常未命中（HTTP 200）。默认结果是未命中标记，不是从范围外选择了一个 Agent。

Collection 选择仅对本次请求生效，不创建库、不切换全局配置。指定库必须兼容服务当前的 embedding 模型、维度和本地 SQLite 路由目录；仅存在于外部库而不存在于本地目录的 Agent 不会成为有效结果。

查询非默认 Collection 时关闭兜底自动学习，避免将语料写回默认库；查询默认 Collection 时沿用现有学习行为。

## 4. BUPT 请求与响应

请求：`POST /compat/bupt/route`（或 `/route`）。

```json
{
  "query": "查询订单物流",
  "collection": "intent_hub",
  "upstream_id": "orders-platform"
}
```

语义命中示例（数值和 Agent 内容仅作格式演示）：

```json
{
  "success": true,
  "data": {
    "matched": true,
    "agents": [
      {"agent": {"id": 71, "title": "订单物流查询"}, "score": 0.93}
    ],
    "text": null,
    "match_source": "semantic",
    "fallback_status": null
  },
  "error": null
}
```

无有效候选示例（启用 LLM 兜底时）：

```json
{
  "success": true,
  "data": {
    "matched": false,
    "agents": [],
    "text": "没有找到合适的 Agent",
    "match_source": "default",
    "fallback_status": "no_candidates"
  },
  "error": null
}
```

`text` 为部署配置的默认文本，不保证与示例相同。`agents[].agent` 是本地路由的原始 `details` 对象，字段由来源决定，也可能为空；调用方不能假定始终包含 `id` 或 `title`。

语义命中可能返回多个达标 Agent，按相似度降序排列，每个 Agent 保留最高分。LLM 兜底命中只返回选中的 Agent，此时 `match_source="llm_fallback"`、`fallback_status="matched"`、`score=null`。

## 5. master 请求与响应

请求：`POST /compat/master/predict`（或 `/predict`）。

```json
{
  "text": "查询订单物流",
  "collection": "intent_hub",
  "upstream_id": "orders-platform",
  "learn_from_fallback": false
}
```

语义命中示例：

```json
[
  {
    "id": 1,
    "name": "订单物流查询",
    "route_key": "orders.71",
    "score": 0.93,
    "match_source": "semantic",
    "fallback_status": null
  }
]
```

`id` 为本地路由 ID；`route_key` 是业务路由标识，不能与上游 ID 混用。未命中返回一个默认结果对象组成的数组，`match_source="default"`、`score=null`；其 `id`、`name`、`route_key` 由部署配置决定。不能仅凭数组非空判断命中。

## 6. 判定口径与错误处理

只有 `lifecycle_status="active"` 的本地路由可以命中。语义分数达到该路由的 `score_threshold` 才通过；负例分数达到 `negative_threshold` 时排除该路由。`score` 是向量相似度，不是概率或 LLM 置信度。

| `fallback_status` | 含义 |
| --- | --- |
| null | 语义命中，或未启用 LLM 兜底 |
| `matched` | LLM 从候选中选择了一个路由 |
| `no_match` | LLM 判断候选均不适用 |
| `ambiguous` | 候选有歧义，可提示用户补充信息 |
| `no_candidates` | 没有有效兜底候选 |
| `unavailable` | 兜底调用、解析或候选选择等环节不可用 |

| HTTP 状态 | 含义 |
| --- | --- |
| 200 | 请求处理成功，包含命中与未命中；LLM 兜底失败也可能以 `default/unavailable` 返回 200 |
| 400 | 参数校验失败或指定 Collection 不存在 |
| 401 | 缺少或无效凭据 |
| 503 | 路由组件尚未就绪；master 也将其他 RuntimeError 映射为 503 |
| 500 | 其他未处理的运行错误 |

BUPT 参数错误示例：

```json
{
  "success": false,
  "data": null,
  "error": {
    "code": "INVALID_REQUEST",
    "message": "请求参数错误",
    "detail": "collection 'missing' 不存在"
  }
}
```

BUPT 其他错误码包括 `UNAUTHORIZED`、`SERVICE_NOT_READY`、`INTERNAL_ERROR`。master 错误返回 `{"error":"错误说明","detail":"详细说明"}`，不使用 BUPT 信封。

## 7. PowerShell 调用示例

```powershell
$baseUrl = 'http://localhost:8000' # 替换为实际后端地址
$headers = @{ Authorization = "Bearer $env:INTENT_HUB_ROUTE_KEY" }
$body = @{
    query = '查询订单物流'
    collection = 'intent_hub'
    upstream_id = 'orders-platform'
} | ConvertTo-Json

Invoke-RestMethod -Method Post -Uri "$baseUrl/compat/bupt/route" `
    -Headers $headers -ContentType 'application/json; charset=utf-8' `
    -Body ([System.Text.Encoding]::UTF8.GetBytes($body))
```

先在本机环境中设置 `INTENT_HUB_ROUTE_KEY`。该变量是示例客户端读取密钥的变量名，不是服务端配置项。省略不需要的筛选字段即可使用默认行为。
